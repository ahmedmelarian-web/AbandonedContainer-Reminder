# Container Reminder (v1.0.0)

Native Android app (Kotlin, XML views, SQLite). Tracks containers and customs-certificate status at a
container terminal and sends local reminder notifications. Everything is stored on the device: no account, no server.

## Build and install the APK

**Option A: Android Studio (easiest)**
1. Install Android Studio (Koala or newer). Open the `ContainerReminder` folder.
2. Let Gradle sync (it downloads Gradle 8.7, Android Gradle Plugin 8.5.2 and the Android SDK 34 on first run).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`. The file is `app/build/outputs/apk/debug/app-debug.apk`.
4. Copy it to the phone and open it (allow "install unknown apps"), or plug the phone in (USB debugging) and press Run.

**Option B: command line** (JDK 17 and Android SDK installed, `ANDROID_HOME` set)
```
gradle wrapper --gradle-version 8.7     # once, creates ./gradlew
./gradlew assembleDebug                 # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease               # smaller, R8-minified: app/build/outputs/apk/release/app-release.apk
adb install -r app/build/outputs/apk/release/app-release.apk
```
The release build is signed with the debug key so it installs; add your own signing config before distributing widely.
Requires Android 8.0 (API 26) or newer. Only three small AndroidX libraries are used, so the APK should be a few MB.

## Excel format
Columns (header names are case/space-insensitive): **Serial, Container Number, ISO, Container Status, Days Status**.
Optional columns (written by Export, read by Import so an export is a full backup): Reminder Threshold (Days), Notes.
A second sheet "Notification Log" (Container Number, Date, Note) restores notification history.
`.xlsx` and `.csv` are read. Old `.xls` must be re-saved as `.xlsx`. The first sheet containing a "Container Number" header is used.

Container Status text: anything with "not" (e.g. "Certificate Not Opened", "No") = not opened; "open"/"cert"/"yes"/"1" = opened.

## Behaviour and rules
- **Matching:** by Container Number (upper-cased, spaces/hyphens removed). Never duplicates; a repeated row in a file is merged.
- **Import preserves:** containers missing from the new file (never deleted), notes, custom thresholds, notification history, and
  manual edits of Status and ISO. A manually edited field is protected until the file's value matches it, then it follows the file again.
- **Import updates:** Serial, Days Status (always taken from the file), and Status/ISO when not manually edited. New containers are added.
- **Days Status** is treated as "days as of the day it was imported/edited" and keeps counting up by one per day on the device.
- **Reminder rule:** threshold = container custom value, else its shipping line's value, else the global default (Settings).
  Not-opened containers become *Due soon* at (threshold minus warning lead days) and *Overdue* at the threshold. Opened = done.
- **Shipping lines:** derived from the container-number prefix (first 3 letters, e.g. MSK, HLC). Lines are auto-created on import
  with default rules; edit name, prefixes (several per line, e.g. `HLC,HLX`), threshold, lead days, on/off in *Shipping lines*.
  Nothing is hard-coded to specific lines.
- **ISO:** decodes ISO 6346 codes (22G1 = 20' Dry, 45R1 = 40' High Cube Reefer, 42U1 Open Top, 22T0 Tank...) and legacy codes (20GP, 40HC, 40RH).
- **Notifications:** one AlarmManager alarm per day at the chosen time (default 09:00) posts a summary of due/overdue containers, also with the
  app closed. Re-armed after reboot, time change, app update and whenever the app opens. Containers with a notification record dated within the
  "quiet period" (default 1 day) are left out, so documenting a follow-up silences it. Alarms are inexact (no exact-alarm permission); delivery can be minutes late.

## Source map (`app/src/main/java/com/containerreminder`)
`Models.kt` data classes, `Db.kt` SQLite, `Reminders.kt` rules, `Iso.kt` ISO decoder, `Xlsx.kt` zero-dependency xlsx/csv reader + xlsx writer,
`DataIO.kt` import/export logic, `Notifier.kt` alarms + notification + receiver, `*Activity.kt` screens, `Util.kt` parsing helpers and settings.

## Not yet verified (needs testing on a device)
This first version was written without being compiled or run. Expect to fix small compile errors on first sync. Test in particular:
1. Gradle sync/build and the APK size.
2. Import of your real Excel files (especially ones with merged cells, a different sheet order, numbers stored as text, or very large files).
3. Export then re-import round trip, and opening the exported file in Excel/Google Sheets/LibreOffice.
4. Merge behaviour on a second import (manual edits kept, no duplicates).
5. Notifications with the app closed: permission prompt on Android 13+, delivery at the set time, after reboot, and under battery optimisation on your phone brand.
6. Day counting across midnight, and the ISO decoding against the codes in your terminal's data.
