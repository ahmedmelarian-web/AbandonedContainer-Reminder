package com.containerreminder

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.containerreminder.databinding.ActivityRecyclerBinding
import com.containerreminder.databinding.ItemLineBinding

/**
 * Reminder rules per shipping line. A line owns one or more container-number prefixes
 * (e.g. MSK, or HLC + HLX). Lines are created automatically on import; none are hard-coded.
 */
class LinesActivity : BaseActivity() {
    private lateinit var b: ActivityRecyclerBinding
    private val adapter = Adapter()
    private var counts: Map<Long, Int> = emptyMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRecyclerBinding.inflate(layoutInflater)
        setContentView(b.root)
        enableUp()
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        val db = Db.get(this)
        val lines = db.lines()
        val m = HashMap<Long, Int>()
        db.allContainers().forEach { c -> Reminders.lineFor(c.number, lines)?.let { m[it.id] = (m[it.id] ?: 0) + 1 } }
        counts = m
        adapter.items = lines
        adapter.notifyDataSetChanged()
        b.tvEmpty.visibility = if (lines.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Add").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS or MenuItem.SHOW_AS_ACTION_WITH_TEXT)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) { edit(null); return true }
        return super.onOptionsItemSelected(item)
    }

    private fun field(box: LinearLayout, hint: String, text: String, type: Int): EditText {
        val e = EditText(this).apply { this.hint = hint; setText(text); inputType = type }
        box.addView(e)
        return e
    }

    private fun edit(line: ShippingLine?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = field(box, "Name (e.g. Maersk)", line?.name ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        val prefixes = field(box, "Container prefixes, comma separated (e.g. MSK or HLC,HLX)", line?.prefixes ?: "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)
        val thr = field(box, "Reminder threshold in days (empty = default)", line?.thresholdDays?.toString() ?: "", InputType.TYPE_CLASS_NUMBER)
        val lead = field(box, "Warn days before threshold (empty = default)", line?.leadDays?.toString() ?: "", InputType.TYPE_CLASS_NUMBER)
        val enabled = CheckBox(this).apply { text = "Reminders enabled for this line"; isChecked = line?.enabled ?: true }
        box.addView(enabled)

        val dlg = AlertDialog.Builder(this).setTitle(if (line == null) "New shipping line" else "Edit shipping line")
            .setView(box).setPositiveButton("Save", null).setNegativeButton("Cancel", null)
        if (line != null) dlg.setNeutralButton("Delete") { _, _ ->
            Db.get(this).deleteLine(line.id); load()
        }
        val d = dlg.create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val db = Db.get(this)
            val pf = prefixes.text.toString().split(',', ';', ' ').map { Parse.number(it) }.filter { it.isNotEmpty() }.distinct()
            val nm = name.text.toString().trim()
            if (nm.isEmpty() || pf.isEmpty()) { toast("Name and at least one prefix are required"); return@setOnClickListener }
            val clash = db.lines().firstOrNull { o -> o.id != (line?.id ?: 0L) && o.prefixList().any { it in pf } }
            if (clash != null) { toast("A prefix is already used by ${clash.name}"); return@setOnClickListener }
            db.saveLine(ShippingLine(line?.id ?: 0L, nm, pf.joinToString(","),
                Parse.intLoose(thr.text.toString()), Parse.intLoose(lead.text.toString()), enabled.isChecked))
            d.dismiss(); load()
        }
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        var items: List<ShippingLine> = emptyList()
        inner class VH(val b: ItemLineBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemLineBinding.inflate(LayoutInflater.from(p.context), p, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(h: VH, i: Int) {
            val l = items[i]
            h.b.tvName.text = l.name
            val prefs = Prefs(this@LinesActivity)
            h.b.tvDetail.text = "Prefixes: ${l.prefixList().joinToString(", ")}\n" +
                "Threshold: ${l.thresholdDays?.let { "$it days" } ?: "default (${prefs.defaultThreshold})"}  |  " +
                "Warn: ${l.leadDays?.let { "$it days before" } ?: "default (${prefs.defaultLead})"}\n" +
                "${if (l.enabled) "Reminders on" else "Reminders OFF"}  |  ${counts[l.id] ?: 0} containers"
            h.b.root.setOnClickListener { edit(l) }
        }
    }
}
