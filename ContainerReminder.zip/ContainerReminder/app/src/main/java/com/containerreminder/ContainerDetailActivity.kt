package com.containerreminder

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.containerreminder.databinding.ActivityDetailBinding
import java.time.LocalDate

class ContainerDetailActivity : BaseActivity() {
    private lateinit var b: ActivityDetailBinding
    private lateinit var db: Db
    private var current: Container? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(b.root)
        enableUp()
        db = Db.get(this)

        val id = intent.getLongExtra("id", 0L)
        current = if (id != 0L) db.getContainer(id) else null
        title = if (current == null) "New container" else "Container"

        b.spStatus.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Certificate not opened", "Certificate opened")
        )

        val c = current
        if (c != null) {
            b.etNumber.setText(c.number); b.etNumber.isEnabled = false
            b.etSerial.setText(c.serial?.toString() ?: "")
            b.etIso.setText(c.iso)
            b.spStatus.setSelection(c.status)
            b.etDays.setText(Reminders.effectiveDays(c, LocalDate.now()).toString())
            b.etThreshold.setText(c.thresholdDays?.toString() ?: "")
            b.etNotes.setText(c.notes)
        } else {
            b.etDays.setText("0")
            b.btnDelete.visibility = View.GONE
            b.logSection.visibility = View.GONE
        }
        updateIsoInfo()
        b.etIso.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) = updateIsoInfo()
        })

        b.btnSave.setOnClickListener { save() }
        b.btnDelete.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Delete container?")
                .setMessage("This also deletes its notification history.")
                .setPositiveButton("Delete") { _, _ -> current?.let { db.deleteContainer(it.id) }; finish() }
                .setNegativeButton("Cancel", null).show()
        }
        b.btnAddLog.setOnClickListener { addLogDialog() }
        renderLogs()
        refreshRule()
    }

    private fun updateIsoInfo() {
        val raw = b.etIso.text.toString()
        val info = Iso.parse(raw)
        b.tvIsoInfo.text = if (raw.isBlank()) "" else "${info.category}: ${info.description}"
    }

    private fun refreshRule() {
        val c = current ?: run { b.tvRule.text = ""; return }
        val prefs = Prefs(this)
        val e = Reminders.evaluate(c, db.lines(), prefs, LocalDate.now())
        val source = when {
            c.thresholdDays != null -> "custom"
            e.line?.thresholdDays != null -> "${e.line?.name} rule"
            else -> "default"
        }
        val state = when (e.state) {
            State.DONE -> "certificate opened"
            State.OVERDUE -> "OVERDUE"
            State.UPCOMING -> "due soon"
            State.OK -> "on track"
        }
        b.tvRule.text = "Today: day ${e.days}  |  limit ${e.threshold} days ($source)  |  $state"
    }

    private fun save() {
        val number = Parse.number(b.etNumber.text.toString())
        if (number.isEmpty()) { toast("Enter a container number"); return }
        val dup = db.getByNumber(number)
        if (dup != null && dup.id != (current?.id ?: 0L)) { toast("A container with this number already exists"); return }

        val thrText = b.etThreshold.text.toString().trim()
        val threshold = if (thrText.isEmpty()) null else thrText.toIntOrNull()
        if (thrText.isNotEmpty() && threshold == null) { toast("Threshold must be a number"); return }
        val iso = b.etIso.text.toString().trim().uppercase().replace(" ", "")
        val status = b.spStatus.selectedItemPosition
        val days = b.etDays.text.toString().toIntOrNull() ?: 0
        val serial = b.etSerial.text.toString().toIntOrNull()
        val notes = b.etNotes.text.toString().trim()
        val today = LocalDate.now().toString()
        val old = current

        val saved = if (old == null) {
            Container(number = number, serial = serial, iso = iso, status = status, daysStatus = days,
                daysBase = today, thresholdDays = threshold, notes = notes, updatedAt = System.currentTimeMillis())
        } else {
            var flags = old.manualFlags
            if (status != old.status) flags = flags or Manual.STATUS
            if (iso != old.iso) flags = flags or Manual.ISO
            old.copy(serial = serial, iso = iso, status = status, manualFlags = flags, daysStatus = days,
                daysBase = today, thresholdDays = threshold, notes = notes, updatedAt = System.currentTimeMillis())
        }
        val newId = db.saveContainer(saved)
        db.ensureLine(number, db.lines().toMutableList())
        current = saved.copy(id = newId)
        toast("Saved")
        finish()
    }

    // ---------------- notification history ----------------
    private fun renderLogs() {
        val c = current ?: return
        b.logList.removeAllViews()
        val logs = db.logs(c.id)
        if (logs.isEmpty()) {
            b.logList.addView(TextView(this).apply { text = "No notifications recorded yet."; setPadding(0, dp(8), 0, 0) })
            return
        }
        for (l in logs) {
            b.logList.addView(TextView(this).apply {
                text = if (l.note.isBlank()) l.date else "${l.date}  -  ${l.note}"
                textSize = 14f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundResource(R.drawable.bg_card)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
                setOnClickListener {
                    AlertDialog.Builder(this@ContainerDetailActivity).setTitle("Delete this record?")
                        .setMessage(text)
                        .setPositiveButton("Delete") { _, _ -> db.deleteLog(l.id); renderLogs() }
                        .setNegativeButton("Cancel", null).show()
                }
            })
        }
    }

    private fun addLogDialog() {
        val c = current ?: return
        var date = LocalDate.now()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val btnDate = Button(this).apply { text = "Date: $date" }
        val note = EditText(this).apply {
            hint = "Note: who was notified, follow-up action..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 2
        }
        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d -> date = LocalDate.of(y, m + 1, d); btnDate.text = "Date: $date" },
                date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        box.addView(btnDate); box.addView(note)
        AlertDialog.Builder(this).setTitle("Add notification record").setView(box)
            .setPositiveButton("Save") { _, _ ->
                db.addLog(c.id, date.toString(), note.text.toString().trim())
                renderLogs()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
