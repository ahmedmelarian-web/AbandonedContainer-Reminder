package com.containerreminder

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.OutputStream
import java.util.TreeMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Reads .xlsx (and simple CSV) into rows of strings. One entry per worksheet. */
object Tables {
    fun read(bytes: ByteArray): List<List<List<String>>> =
        if (bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) Xlsx.read(bytes)
        else if (bytes.size > 3 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte())
            throw IllegalArgumentException("Old .xls format is not supported. In Excel use Save As > .xlsx and import that file.")
        else listOf(parseCsv(String(bytes, Charsets.UTF_8)))

    private fun parseCsv(text: String): List<List<String>> {
        val t = text.removePrefix("\uFEFF")
        val first = t.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> first.count { it == d } } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < t.length) {
            val ch = t[i]
            if (quoted) {
                if (ch == '"') {
                    if (i + 1 < t.length && t[i + 1] == '"') { sb.append('"'); i++ } else quoted = false
                } else sb.append(ch)
            } else if (ch == '"') quoted = true
            else if (ch == delim) { row.add(sb.toString()); sb.setLength(0) }
            else if (ch == '\n') { row.add(sb.toString()); sb.setLength(0); rows.add(row); row = ArrayList() }
            else if (ch != '\r') sb.append(ch)
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); rows.add(row) }
        return rows
    }
}

/** Minimal, dependency-free XLSX reader/writer (Apache POI is far too large for a small APK). */
object Xlsx {
    private val SHEET_RE = Regex("xl/worksheets/sheet(\\d+)\\.xml")

    // ------------------------------ READ ------------------------------
    fun read(bytes: ByteArray): List<List<List<String>>> {
        var shared: List<String> = emptyList()
        val sheets = TreeMap<Int, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name
                if (name == "xl/sharedStrings.xml") shared = parseShared(zin.readBytes())
                else SHEET_RE.matchEntire(name)?.let { sheets[it.groupValues[1].toInt()] = zin.readBytes() }
                e = zin.nextEntry
            }
        }
        if (sheets.isEmpty()) throw IllegalArgumentException("No worksheets found. Is this a valid .xlsx file?")
        return sheets.values.map { parseSheet(it, shared) }
    }

    private fun parser(b: ByteArray): XmlPullParser =
        Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), null) }

    private fun parseShared(xml: ByteArray): List<String> {
        val p = parser(xml)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inT = false
        var inPhonetic = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) { "si" -> sb.setLength(0); "rPh" -> inPhonetic = true; "t" -> inT = true }
            } else if (ev == XmlPullParser.TEXT) {
                if (inT && !inPhonetic) sb.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) { "t" -> inT = false; "rPh" -> inPhonetic = false; "si" -> out.add(sb.toString()) }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun parseSheet(xml: ByteArray, shared: List<String>): List<List<String>> {
        val p = parser(xml)
        val rows = ArrayList<List<String>>()
        var row: MutableList<String>? = null
        var col = 0
        var type: String? = null
        var inText = false
        val sb = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> row = ArrayList()
                    "c" -> {
                        type = p.getAttributeValue(null, "t")
                        val ref = p.getAttributeValue(null, "r")
                        col = if (ref != null) colIndex(ref) else (row?.size ?: 0)
                        sb.setLength(0)
                    }
                    "v", "t" -> inText = true
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inText) sb.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "v", "t" -> inText = false
                    "c" -> {
                        val raw = sb.toString()
                        val value = if (type == "s") shared.getOrElse(raw.trim().toIntOrNull() ?: -1) { "" } else raw
                        val r = row
                        if (r != null && col >= 0) {
                            while (r.size < col) r.add("")
                            if (r.size == col) r.add(value) else r[col] = value
                        }
                    }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            ev = p.next()
        }
        return rows
    }

    // ------------------------------ WRITE ------------------------------
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    /** First row of every sheet is written bold as a header. Cell values: Number, String or null. */
    fun write(out: OutputStream, sheets: List<Pair<String, List<List<Any?>>>>) {
        val zip = ZipOutputStream(out)
        fun put(name: String, content: String) {
            zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
        }
        val overrides = sheets.indices.joinToString("") {
            "<Override PartName=\"/xl/worksheets/sheet${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
        }
        put("[Content_Types].xml", HEAD +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            overrides +
            "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>")
        put("_rels/.rels", HEAD +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"$REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        put("xl/workbook.xml", HEAD + "<workbook xmlns=\"$NS\" xmlns:r=\"$REL\"><sheets>" +
            sheets.mapIndexed { i, s -> "<sheet name=\"${esc(s.first)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>" }.joinToString("") +
            "</sheets></workbook>")
        put("xl/_rels/workbook.xml.rels", HEAD +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            sheets.indices.joinToString("") { "<Relationship Id=\"rId${it + 1}\" Type=\"$REL/worksheet\" Target=\"worksheets/sheet${it + 1}.xml\"/>" } +
            "<Relationship Id=\"rId${sheets.size + 1}\" Type=\"$REL/styles\" Target=\"styles.xml\"/></Relationships>")
        put("xl/styles.xml", HEAD + "<styleSheet xmlns=\"$NS\">" +
            "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>")
        sheets.forEachIndexed { i, s -> put("xl/worksheets/sheet${i + 1}.xml", sheetXml(s.second)) }
        zip.finish()
        zip.flush()
    }

    private fun sheetXml(rows: List<List<Any?>>): String {
        val sb = StringBuilder(HEAD)
        val cols = (rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
        sb.append("<worksheet xmlns=\"$NS\">")
        sb.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>")
        sb.append("<cols><col min=\"1\" max=\"$cols\" width=\"20\" customWidth=\"1\"/></cols><sheetData>")
        rows.forEachIndexed { r, row ->
            sb.append("<row r=\"${r + 1}\">")
            row.forEachIndexed { c, v ->
                val ref = colName(c) + (r + 1)
                val style = if (r == 0) " s=\"1\"" else ""
                when {
                    v == null || (v is String && v.isEmpty()) -> {}
                    v is Number -> sb.append("<c r=\"$ref\"$style><v>$v</v></c>")
                    else -> sb.append("<c r=\"$ref\"$style t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.toString())}</t></is></c>")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun colName(i: Int): String {
        var n = i + 1
        val s = StringBuilder()
        while (n > 0) { val r = (n - 1) % 26; s.insert(0, 'A' + r); n = (n - 1) / 26 }
        return s.toString()
    }

    private fun esc(s: String): String =
        s.filter { it == '\n' || it == '\t' || it >= ' ' }
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}
