package com.containerreminder

import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
    /** Call after setContentView. */
    protected fun enableUp() { supportActionBar?.setDisplayHomeAsUpEnabled(true) }
    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
