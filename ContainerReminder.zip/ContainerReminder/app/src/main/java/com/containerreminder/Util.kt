package com.containerreminder

import android.content.Context
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

object Parse {
    /** Normalises a container number: upper case, letters and digits only. */
    fun number(raw: String): String = raw.uppercase().filter { it.isLetterOrDigit() }

    fun intLoose(raw: String?): Int? =
        raw?.trim()?.toDoubleOrNull()?.takeIf { it.isFinite() }?.toInt()

    /** Returns null when the text is empty or not understood. */
    fun status(raw: String): Int? {
        val t = raw.trim().lowercase()
        if (t.isEmpty()) return null
        val negative = t in setOf("0", "no", "n", "false", "closed", "pending") ||
            t.contains("not") || t.contains("unopen") || t.contains("without") || t.contains("no cert")
        if (negative) return Status.NOT_OPENED
        val positive = t in setOf("1", "yes", "y", "true") ||
            t.contains("open") || t.contains("cert") || t.contains("released")
        return if (positive) Status.OPENED else null
    }

    private val formats = listOf("yyyy-MM-dd", "d/M/yyyy", "yyyy/M/d", "d.M.yyyy", "d-M-yyyy")
        .map { DateTimeFormatter.ofPattern(it) }

    /** Accepts ISO dates, day-first dates, and Excel date serial numbers. */
    fun date(raw: String): LocalDate? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        t.toDoubleOrNull()?.let {
            if (it in 20000.0..80000.0) return LocalDate.of(1899, 12, 30).plusDays(it.toLong())
        }
        val core = t.substringBefore(' ').substringBefore('T')
        for (f in formats) {
            try { return LocalDate.parse(core, f) } catch (_: Exception) { }
        }
        return null
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var defaultThreshold: Int
        get() = sp.getInt("thr", 5)
        set(v) = sp.edit().putInt("thr", v).apply()
    var defaultLead: Int
        get() = sp.getInt("lead", 1)
        set(v) = sp.edit().putInt("lead", v).apply()
    var quietDays: Int
        get() = sp.getInt("quiet", 1)
        set(v) = sp.edit().putInt("quiet", v).apply()
    var notifyHour: Int
        get() = sp.getInt("hour", 9)
        set(v) = sp.edit().putInt("hour", v).apply()
    var notifyMinute: Int
        get() = sp.getInt("minute", 0)
        set(v) = sp.edit().putInt("minute", v).apply()
    var remindersEnabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) = sp.edit().putBoolean("enabled", v).apply()
}
