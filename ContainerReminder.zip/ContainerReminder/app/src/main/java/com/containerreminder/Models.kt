package com.containerreminder

import java.time.LocalDate

object Status {
    const val NOT_OPENED = 0   // customs certificate not opened
    const val OPENED = 1       // customs certificate opened
}

/** Bit flags: field was edited by hand, so Excel imports must not overwrite it. */
object Manual {
    const val STATUS = 1
    const val ISO = 2
}

data class Container(
    val id: Long = 0,
    val number: String,
    val serial: Int? = null,
    val iso: String = "",
    val status: Int = Status.NOT_OPENED,
    val manualFlags: Int = 0,
    val daysStatus: Int = 0,
    /** Date (yyyy-MM-dd) on which [daysStatus] was recorded. Days keep counting up from here. */
    val daysBase: String = LocalDate.now().toString(),
    /** Custom per-container threshold; null = use shipping line rule or global default. */
    val thresholdDays: Int? = null,
    val notes: String = "",
    val updatedAt: Long = 0
)

data class ShippingLine(
    val id: Long = 0,
    val name: String,
    /** Comma separated container-number prefixes, e.g. "MSK" or "HLC,HLX". */
    val prefixes: String,
    val thresholdDays: Int? = null,
    val leadDays: Int? = null,
    val enabled: Boolean = true
) {
    fun prefixList(): List<String> =
        prefixes.split(',', ';', ' ').map { it.trim().uppercase() }.filter { it.isNotEmpty() }
}

data class LogEntry(val id: Long, val containerId: Long, val date: String, val note: String)

enum class State { DONE, OK, UPCOMING, OVERDUE }

data class Eval(
    val c: Container,
    val line: ShippingLine?,
    val days: Int,
    val threshold: Int,
    val state: State
)
