package com.containerreminder

data class IsoInfo(val category: String, val description: String)

/**
 * Decodes ISO 6346 size/type codes (e.g. 22G1, 45R1, 42U1) and common legacy codes (20GP, 40HC, 40RH).
 * Category is one of: Dry, Reefer, Open Top, Flat Rack, Tank, Special, Unknown.
 */
object Iso {
    private val legacy = Regex("^(20|40|45)(GP|DC|DV|GH|HC|HQ|RF|RH|RE|OT|FR|FL|TK)$")
    private val iso6346 = Regex("^[0-9A-Z][0-9A-Z][A-Z0-9][A-Z0-9]$")

    fun parse(raw: String): IsoInfo {
        val c = raw.trim().uppercase().replace(" ", "")
        if (c.isEmpty()) return IsoInfo("Unknown", "")

        legacy.matchEntire(c)?.let { m ->
            val len = m.groupValues[1] + "'"
            return when (m.groupValues[2]) {
                "GP", "DC", "DV" -> IsoInfo("Dry", "$len Dry")
                "GH", "HC", "HQ" -> IsoInfo("Dry", "$len High Cube Dry")
                "RF", "RE" -> IsoInfo("Reefer", "$len Reefer")
                "RH" -> IsoInfo("Reefer", "$len High Cube Reefer")
                "OT" -> IsoInfo("Open Top", "$len Open Top")
                "FR", "FL" -> IsoInfo("Flat Rack", "$len Flat Rack")
                else -> IsoInfo("Tank", "$len Tank")
            }
        }

        if (!iso6346.matches(c)) return IsoInfo("Unknown", "Unrecognised ISO code")

        val len = when (c[0]) {
            '1' -> "10'"; '2' -> "20'"; '3' -> "30'"; '4' -> "40'"; 'L' -> "45'"; 'M' -> "48'"
            else -> "Size ${c[0]}"
        }
        val height = when (c[1]) {
            '0' -> "Low (8'0\") "; '4' -> "9'0\" "; '5' -> "High Cube "; '6' -> "Extra High "
            '8' -> "Half Height "; '9' -> "Low "
            else -> ""  // '2' = standard 8'6"
        }
        val (cat, type) = when (c[2]) {
            'G' -> "Dry" to "Dry (General Purpose)"
            'V' -> "Dry" to "Dry Ventilated"
            'B' -> "Dry" to "Dry Bulk"
            'S' -> "Special" to "Named Cargo"
            'R' -> "Reefer" to "Reefer"
            'H' -> "Reefer" to "Reefer (Insulated/Heated)"
            'U' -> "Open Top" to "Open Top"
            'P' -> "Flat Rack" to "Flat Rack / Platform"
            'T' -> "Tank" to "Tank"
            'A' -> "Special" to "Air/Surface"
            '0' -> "Dry" to "Dry"
            else -> return IsoInfo("Unknown", "$len type ${c[2]}${c[3]}")
        }
        return IsoInfo(cat, "$len $height$type".replace("  ", " "))
    }
}
