package com.containerreminder

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.containerreminder.databinding.ActivityMainBinding
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val values = HashMap<String, TextView>()
    private val xlsxMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runImport(uri)
    }
    private val exportPicker = registerForActivityResult(ActivityResultContracts.CreateDocument(xlsxMime)) { uri ->
        if (uri != null) runExport(uri)
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        Notifier.schedule(this); refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        buildCards()

        b.btnList.setOnClickListener { openList("ALL") }
        b.btnAdd.setOnClickListener { startActivity(Intent(this, ContainerDetailActivity::class.java)) }
        b.btnImport.setOnClickListener { importPicker.launch(arrayOf("*/*")) }
        b.btnExport.setOnClickListener { exportPicker.launch("container-reminder-${LocalDate.now()}.xlsx") }
        b.btnLines.setOnClickListener { startActivity(Intent(this, LinesActivity::class.java)) }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.tvWarn.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 && !Notifier.canPost(this)) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }
        }

        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        Notifier.schedule(this)   // re-arm the daily alarm whenever the app is opened
        refresh()
    }

    // ---------------- dashboard ----------------
    private fun buildCards() {
        fun card(key: String, label: String, color: Int, filter: String): View {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_card)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                isClickable = true; isFocusable = true
                setOnClickListener { openList(filter) }
            }
            val v = TextView(this).apply { textSize = 30f; setTextColor(color); setTypeface(typeface, android.graphics.Typeface.BOLD); text = "0" }
            val l = TextView(this).apply { textSize = 13f; setTextColor(ContextCompat.getColor(this@MainActivity, R.color.muted)); text = label }
            box.addView(v); box.addView(l)
            values[key] = v
            return box
        }
        fun row(vararg cards: View) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            cards.forEach { c ->
                r.addView(c, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                })
            }
            b.stats.addView(r)
        }
        val c = { id: Int -> ContextCompat.getColor(this, id) }
        row(card("ALL", "Total containers", c(R.color.primary), "ALL"))
        row(card("WITH", "With customs certificate", c(R.color.green), "WITH"),
            card("WITHOUT", "Without certificate", c(R.color.red), "WITHOUT"))
        row(card("UPCOMING", "Upcoming reminders", c(R.color.amber), "UPCOMING"),
            card("OVERDUE", "Overdue containers", Color.parseColor("#B71C1C"), "OVERDUE"))
    }

    private fun refresh() {
        val prefs = Prefs(this)
        val db = Db.get(this)
        val lines = db.lines()
        val today = LocalDate.now()
        val ev = db.allContainers().map { Reminders.evaluate(it, lines, prefs, today) }
        val with = ev.count { it.state == State.DONE }
        values["ALL"]?.text = ev.size.toString()
        values["WITH"]?.text = with.toString()
        values["WITHOUT"]?.text = (ev.size - with).toString()
        values["UPCOMING"]?.text = ev.count { it.state == State.UPCOMING }.toString()
        values["OVERDUE"]?.text = ev.count { it.state == State.OVERDUE }.toString()
        b.tvWarn.visibility =
            if (prefs.remindersEnabled && !NotificationManagerCompat.from(this).areNotificationsEnabled()) View.VISIBLE
            else View.GONE
    }

    private fun openList(filter: String) =
        startActivity(Intent(this, ContainerListActivity::class.java).putExtra("filter", filter))

    // ---------------- import / export ----------------
    private fun runImport(uri: Uri) {
        val progress = AlertDialog.Builder(this).setMessage("Importing...").setCancelable(false).show()
        Thread {
            var res: ImportResult? = null
            var err: String? = null
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                res = Importer.import(applicationContext, Tables.read(bytes))
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            }
            val result = res
            val error = err
            runOnUiThread {
                progress.dismiss()
                if (isFinishing) return@runOnUiThread
                val msg = if (result != null) buildString {
                    append("Added: ${result.added}\nUpdated: ${result.updated}\nUnchanged: ${result.unchanged}\n")
                    if (result.skipped > 0) append("Skipped (no container number): ${result.skipped}\n")
                    if (result.duplicatesInFile > 0) append("Duplicate rows in file (merged): ${result.duplicatesInFile}\n")
                    if (result.logsAdded > 0) append("Notification records restored: ${result.logsAdded}\n")
                    if (result.linesCreated > 0) append("Shipping lines created: ${result.linesCreated}\n")
                    append("\nExisting containers, manual edits, notes and history were kept.")
                } else "Import failed:\n$error"
                AlertDialog.Builder(this).setTitle(if (result != null) "Import complete" else "Import failed")
                    .setMessage(msg).setPositiveButton("OK", null).show()
                Notifier.schedule(this)
                refresh()
            }
        }.start()
    }

    private fun runExport(uri: Uri) {
        try {
            val n = contentResolver.openOutputStream(uri, "wt")!!.use { Exporter.write(applicationContext, it) }
            toast("Exported $n containers")
        } catch (e: Exception) {
            toast("Export failed: ${e.message}")
        }
    }
}
