package com.containerreminder

import android.app.TimePickerDialog
import android.os.Bundle
import com.containerreminder.databinding.ActivitySettingsBinding

class SettingsActivity : BaseActivity() {
    private lateinit var b: ActivitySettingsBinding
    private var hour = 9
    private var minute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        enableUp()
        val p = Prefs(this)
        hour = p.notifyHour; minute = p.notifyMinute
        b.swEnabled.isChecked = p.remindersEnabled
        b.etThreshold.setText(p.defaultThreshold.toString())
        b.etLead.setText(p.defaultLead.toString())
        b.etQuiet.setText(p.quietDays.toString())
        showTime()

        b.btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> hour = h; minute = m; showTime() }, hour, minute, true).show()
        }
        b.btnSave.setOnClickListener {
            val thr = b.etThreshold.text.toString().toIntOrNull()
            val lead = b.etLead.text.toString().toIntOrNull()
            val quiet = b.etQuiet.text.toString().toIntOrNull()
            if (thr == null || lead == null || quiet == null || thr < 0 || lead < 0 || quiet < 0) {
                toast("Enter whole numbers (0 or more)"); return@setOnClickListener
            }
            p.defaultThreshold = thr; p.defaultLead = lead; p.quietDays = quiet
            p.notifyHour = hour; p.notifyMinute = minute; p.remindersEnabled = b.swEnabled.isChecked
            Notifier.schedule(this)
            toast("Settings saved")
            finish()
        }
        b.btnTest.setOnClickListener {
            if (!Notifier.canPost(this)) { toast("Notification permission is not granted. Allow it in Android app settings."); return@setOnClickListener }
            val n = Notifier.run(this, force = true)
            toast(if (n == 0) "Sent. Nothing is due right now." else "Sent notification for $n containers")
        }
    }

    private fun showTime() { b.btnTime.text = "%02d:%02d".format(hour, minute) }
}
