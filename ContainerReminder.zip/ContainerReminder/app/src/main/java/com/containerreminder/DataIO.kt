package com.containerreminder

import android.content.Context
import java.io.OutputStream
import java.time.LocalDate

data class ImportResult(
    var added: Int = 0, var updated: Int = 0, var unchanged: Int = 0, var skipped: Int = 0,
    var duplicatesInFile: Int = 0, var logsAdded: Int = 0, var linesCreated: Int = 0
)

object Importer {
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun canonical(n: String): String? = when (n) {
        "serial", "serialno", "serialnumber", "sn", "no" -> "serial"
        "containernumber", "container", "containerno", "containernr", "cntr", "cntrno", "containerid" -> "number"
        "iso", "isocode", "isotype" -> "iso"
        "containerstatus", "status", "certificatestatus", "certificate" -> "status"
        "daysstatus", "days", "daystatus" -> "days"
        "remindthresholddays", "reminderthresholddays", "reminderthreshold", "threshold" -> "threshold"
        "notes", "note", "remarks", "comment", "comments" -> "note"
        "date", "notificationdate", "notified" -> "date"
        else -> null
    }

    /** Finds the header row (within the first 15 rows) and maps canonical names to column indexes. */
    private fun header(sheet: List<List<String>>): Pair<Int, Map<String, Int>>? {
        for (i in 0 until minOf(sheet.size, 15)) {
            val m = HashMap<String, Int>()
            sheet[i].forEachIndexed { idx, v -> canonical(norm(v))?.let { if (it !in m) m[it] = idx } }
            if ("number" in m) return i to m
        }
        return null
    }

    private fun List<String>.cell(i: Int?): String = if (i == null) "" else getOrNull(i)?.trim() ?: ""

    fun import(ctx: Context, sheets: List<List<List<String>>>): ImportResult {
        val db = Db.get(ctx)
        val res = ImportResult()
        val existing = HashMap<String, Container>()
        db.allContainers().forEach { existing[it.number] = it }
        val lines = db.lines().toMutableList()
        val linesBefore = lines.size
        val today = LocalDate.now().toString()
        val now = System.currentTimeMillis()
        val seen = HashSet<String>()
        var foundContainerSheet = false

        db.writableDatabase.beginTransaction()
        try {
            // Containers first, then notification logs (so logs can refer to freshly added containers).
            val parsed = sheets.mapNotNull { s -> header(s)?.let { Triple(s, it.first, it.second) } }
            val containerSheets = parsed.filter { "date" !in it.third || "status" in it.third || "days" in it.third }
            val logSheets = parsed.filter { it !in containerSheets }

            for ((sheet, h, m) in containerSheets) {
                foundContainerSheet = true
                for (r in sheet.drop(h + 1)) {
                    val number = Parse.number(r.cell(m["number"]))
                    if (number.isEmpty()) { if (r.any { it.isNotBlank() }) res.skipped++; continue }
                    if (!seen.add(number)) res.duplicatesInFile++
                    val serial = Parse.intLoose(r.cell(m["serial"]))
                    val iso = r.cell(m["iso"]).uppercase().replace(" ", "")
                    val st = Parse.status(r.cell(m["status"]))
                    val days = Parse.intLoose(r.cell(m["days"]))
                    val thr = Parse.intLoose(r.cell(m["threshold"]))
                    val note = r.cell(m["note"])
                    val old = existing[number]

                    if (old == null) {
                        val c = Container(
                            number = number, serial = serial, iso = iso, status = st ?: Status.NOT_OPENED,
                            daysStatus = days ?: 0, daysBase = today, thresholdDays = thr, notes = note, updatedAt = now
                        )
                        existing[number] = c.copy(id = db.saveContainer(c))
                        db.ensureLine(number, lines)
                        res.added++
                    } else {
                        // Preserve manual edits: status / ISO the user changed by hand are kept
                        // until the file agrees with the stored value (then the lock is released).
                        var flags = old.manualFlags
                        var status = old.status
                        if (st != null) {
                            if (flags and Manual.STATUS != 0) { if (st == old.status) flags = flags and Manual.STATUS.inv() }
                            else status = st
                        }
                        var isoV = old.iso
                        if (iso.isNotEmpty()) {
                            if (flags and Manual.ISO != 0) { if (iso == old.iso) flags = flags and Manual.ISO.inv() }
                            else isoV = iso
                        }
                        val n = old.copy(
                            serial = serial ?: old.serial, iso = isoV, status = status, manualFlags = flags,
                            daysStatus = days ?: old.daysStatus, daysBase = if (days != null) today else old.daysBase,
                            // user data (threshold, notes) is never overwritten; only filled when empty
                            thresholdDays = old.thresholdDays ?: thr,
                            notes = if (old.notes.isBlank()) note else old.notes
                        )
                        val changed = n.copy(daysBase = old.daysBase) != old
                        if (changed || n.daysBase != old.daysBase) {
                            val saved = n.copy(updatedAt = if (changed) now else old.updatedAt)
                            db.saveContainer(saved); existing[number] = saved
                        }
                        db.ensureLine(number, lines)
                        if (changed) res.updated++ else res.unchanged++
                    }
                }
            }

            for ((sheet, h, m) in logSheets) {
                for (r in sheet.drop(h + 1)) {
                    val c = existing[Parse.number(r.cell(m["number"]))] ?: continue
                    val date = Parse.date(r.cell(m["date"]))?.toString() ?: continue
                    val note = r.cell(m["note"])
                    if (!db.logExists(c.id, date, note)) { db.addLog(c.id, date, note); res.logsAdded++ }
                }
            }
            if (!foundContainerSheet && logSheets.isEmpty())
                throw IllegalArgumentException(
                    "Could not find a 'Container Number' column. Expected columns: Serial, Container Number, ISO, Container Status, Days Status."
                )
            db.writableDatabase.setTransactionSuccessful()
        } finally {
            db.writableDatabase.endTransaction()
        }
        res.linesCreated = lines.size - linesBefore
        return res
    }
}

object Exporter {
    /** Writes the whole database (containers + notification log) as .xlsx. Returns container count. */
    fun write(ctx: Context, out: OutputStream): Int {
        val db = Db.get(ctx)
        val prefs = Prefs(ctx)
        val lines = db.lines()
        val today = LocalDate.now()
        val last = db.lastLogDates()
        val all = db.allContainers()

        val rows = ArrayList<List<Any?>>()
        rows.add(listOf(
            "Serial", "Container Number", "ISO", "Container Status", "Days Status",
            "Shipping Line", "Container Type", "Reminder Threshold (Days)", "Last Notified", "Notes"
        ))
        for (c in all) {
            val e = Reminders.evaluate(c, lines, prefs, today)
            rows.add(listOf(
                c.serial, c.number, c.iso,
                if (c.status == Status.OPENED) "Certificate Opened" else "Certificate Not Opened",
                e.days, e.line?.name ?: "", Iso.parse(c.iso).description,
                c.thresholdDays, last[c.id] ?: "", c.notes
            ))
        }
        val logRows = ArrayList<List<Any?>>()
        logRows.add(listOf("Container Number", "Date", "Note"))
        db.allLogs().forEach { logRows.add(listOf(it.first, it.second, it.third)) }

        Xlsx.write(out, listOf("Containers" to rows, "Notification Log" to logRows))
        return all.size
    }
}
