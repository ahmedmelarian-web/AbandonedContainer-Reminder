package com.containerreminder

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

private const val COLS =
    "id,number,serial,iso,status,manual_flags,days_status,days_base,threshold,notes,updated_at"

private fun ContentValues.putIntOrNull(key: String, v: Int?) {
    if (v == null) putNull(key) else put(key, v)
}

class Db private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "container_reminder.db", null, 1) {

    companion object {
        @Volatile private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) { inst ?: Db(ctx).also { inst = it } }
    }

    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE containers (id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL UNIQUE, " +
                "serial INTEGER, iso TEXT NOT NULL DEFAULT '', status INTEGER NOT NULL DEFAULT 0, " +
                "manual_flags INTEGER NOT NULL DEFAULT 0, days_status INTEGER NOT NULL DEFAULT 0, " +
                "days_base TEXT NOT NULL, threshold INTEGER, notes TEXT NOT NULL DEFAULT '', " +
                "updated_at INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE lines (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "prefixes TEXT NOT NULL, threshold INTEGER, lead INTEGER, enabled INTEGER NOT NULL DEFAULT 1)"
        )
        db.execSQL(
            "CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "container_id INTEGER NOT NULL REFERENCES containers(id) ON DELETE CASCADE, " +
                "date TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')"
        )
        db.execSQL("CREATE INDEX idx_logs_container ON logs(container_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Future schema migrations go here (use ALTER TABLE, never drop user data).
    }

    // ---------- containers ----------
    private fun Cursor.toContainer() = Container(
        id = getLong(0), number = getString(1),
        serial = if (isNull(2)) null else getInt(2),
        iso = getString(3), status = getInt(4), manualFlags = getInt(5),
        daysStatus = getInt(6), daysBase = getString(7),
        thresholdDays = if (isNull(8)) null else getInt(8),
        notes = getString(9), updatedAt = getLong(10)
    )

    private fun Container.toValues() = ContentValues().apply {
        put("number", number); putIntOrNull("serial", serial); put("iso", iso)
        put("status", status); put("manual_flags", manualFlags)
        put("days_status", daysStatus); put("days_base", daysBase)
        putIntOrNull("threshold", thresholdDays); put("notes", notes); put("updated_at", updatedAt)
    }

    fun allContainers(): List<Container> =
        readableDatabase.rawQuery(
            "SELECT $COLS FROM containers ORDER BY COALESCE(serial, 999999999), number", null
        ).use { c -> buildList { while (c.moveToNext()) add(c.toContainer()) } }

    fun getContainer(id: Long): Container? =
        readableDatabase.rawQuery("SELECT $COLS FROM containers WHERE id=?", arrayOf(id.toString()))
            .use { if (it.moveToFirst()) it.toContainer() else null }

    fun getByNumber(number: String): Container? =
        readableDatabase.rawQuery("SELECT $COLS FROM containers WHERE number=?", arrayOf(number))
            .use { if (it.moveToFirst()) it.toContainer() else null }

    /** Inserts (id == 0) or updates. Returns the row id. */
    fun saveContainer(c: Container): Long {
        val v = c.toValues()
        return if (c.id == 0L) writableDatabase.insertOrThrow("containers", null, v)
        else { writableDatabase.update("containers", v, "id=?", arrayOf(c.id.toString())); c.id }
    }

    fun deleteContainer(id: Long) {
        writableDatabase.delete("containers", "id=?", arrayOf(id.toString()))
    }

    // ---------- shipping lines ----------
    fun lines(): List<ShippingLine> =
        readableDatabase.rawQuery(
            "SELECT id,name,prefixes,threshold,lead,enabled FROM lines ORDER BY name COLLATE NOCASE", null
        ).use { c ->
            buildList {
                while (c.moveToNext()) add(
                    ShippingLine(
                        c.getLong(0), c.getString(1), c.getString(2),
                        if (c.isNull(3)) null else c.getInt(3),
                        if (c.isNull(4)) null else c.getInt(4),
                        c.getInt(5) == 1
                    )
                )
            }
        }

    fun saveLine(l: ShippingLine): Long {
        val v = ContentValues().apply {
            put("name", l.name); put("prefixes", l.prefixes)
            putIntOrNull("threshold", l.thresholdDays); putIntOrNull("lead", l.leadDays)
            put("enabled", if (l.enabled) 1 else 0)
        }
        return if (l.id == 0L) writableDatabase.insertOrThrow("lines", null, v)
        else { writableDatabase.update("lines", v, "id=?", arrayOf(l.id.toString())); l.id }
    }

    fun deleteLine(id: Long) { writableDatabase.delete("lines", "id=?", arrayOf(id.toString())) }

    /** Creates a line named after the first 3 letters of the container number if no line covers it yet. */
    fun ensureLine(number: String, lines: MutableList<ShippingLine>) {
        if (Reminders.lineFor(number, lines) != null) return
        val p = number.take(3)
        if (p.length < 3) return
        val l = ShippingLine(0, p, p)
        lines.add(l.copy(id = saveLine(l)))
    }

    // ---------- notification log ----------
    fun logs(containerId: Long): List<LogEntry> =
        readableDatabase.rawQuery(
            "SELECT id,container_id,date,note FROM logs WHERE container_id=? ORDER BY date DESC, id DESC",
            arrayOf(containerId.toString())
        ).use { c -> buildList { while (c.moveToNext()) add(LogEntry(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3))) } }

    fun addLog(containerId: Long, date: String, note: String) {
        writableDatabase.insert("logs", null, ContentValues().apply {
            put("container_id", containerId); put("date", date); put("note", note)
        })
    }

    fun deleteLog(id: Long) { writableDatabase.delete("logs", "id=?", arrayOf(id.toString())) }

    fun logExists(containerId: Long, date: String, note: String): Boolean =
        readableDatabase.rawQuery(
            "SELECT 1 FROM logs WHERE container_id=? AND date=? AND note=? LIMIT 1",
            arrayOf(containerId.toString(), date, note)
        ).use { it.moveToFirst() }

    fun lastLogDates(): Map<Long, String> =
        readableDatabase.rawQuery("SELECT container_id, MAX(date) FROM logs GROUP BY container_id", null)
            .use { c -> HashMap<Long, String>().also { m -> while (c.moveToNext()) m[c.getLong(0)] = c.getString(1) } }

    /** (container number, date, note) for every record, for export. */
    fun allLogs(): List<Triple<String, String, String>> =
        readableDatabase.rawQuery(
            "SELECT c.number, l.date, l.note FROM logs l JOIN containers c ON c.id=l.container_id " +
                "ORDER BY c.number, l.date, l.id", null
        ).use { c -> buildList { while (c.moveToNext()) add(Triple(c.getString(0), c.getString(1), c.getString(2))) } }
}
