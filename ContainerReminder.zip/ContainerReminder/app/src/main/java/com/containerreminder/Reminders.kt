package com.containerreminder

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object Reminders {

    /** Longest matching prefix wins, so "HLCU" can override "HLC" if the user wants. */
    fun lineFor(number: String, lines: List<ShippingLine>): ShippingLine? {
        var best: ShippingLine? = null
        var bestLen = 0
        for (l in lines) for (p in l.prefixList()) {
            if (p.length > bestLen && number.startsWith(p)) { best = l; bestLen = p.length }
        }
        return best
    }

    /** Days keep counting after import: stored days + days elapsed since they were recorded. */
    fun effectiveDays(c: Container, today: LocalDate): Int {
        val base = try { LocalDate.parse(c.daysBase) } catch (e: Exception) { today }
        return (c.daysStatus + ChronoUnit.DAYS.between(base, today).toInt()).coerceAtLeast(0)
    }

    fun evaluate(c: Container, lines: List<ShippingLine>, prefs: Prefs, today: LocalDate): Eval {
        val line = lineFor(c.number, lines)
        val threshold = c.thresholdDays ?: line?.thresholdDays ?: prefs.defaultThreshold
        val lead = line?.leadDays ?: prefs.defaultLead
        val days = effectiveDays(c, today)
        val active = c.thresholdDays != null || line?.enabled != false
        val state = when {
            c.status == Status.OPENED -> State.DONE
            !active -> State.OK
            days >= threshold -> State.OVERDUE
            days >= threshold - lead -> State.UPCOMING
            else -> State.OK
        }
        return Eval(c, line, days, threshold, state)
    }
}
