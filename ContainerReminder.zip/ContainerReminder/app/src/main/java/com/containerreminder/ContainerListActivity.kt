package com.containerreminder

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.containerreminder.databinding.ActivityListBinding
import com.containerreminder.databinding.ItemContainerBinding
import java.time.LocalDate

class ContainerListActivity : BaseActivity() {
    private lateinit var b: ActivityListBinding
    private val adapter = Adapter()
    private var all: List<Eval> = emptyList()
    private var lastLogs: Map<Long, String> = emptyMap()

    private val filters = listOf(
        "ALL" to "All containers",
        "WITH" to "With customs certificate (opened)",
        "WITHOUT" to "Without certificate (not opened)",
        "UPCOMING" to "Upcoming reminders",
        "OVERDUE" to "Overdue"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        enableUp()

        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter
        b.spFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, filters.map { it.second })
        val initial = filters.indexOfFirst { it.first == intent.getStringExtra("filter") }.coerceAtLeast(0)
        b.spFilter.setSelection(initial)
        b.spFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = applyFilter()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })
    }

    override fun onResume() {
        super.onResume()
        val db = Db.get(this)
        val lines = db.lines()
        val today = LocalDate.now()
        val prefs = Prefs(this)
        all = db.allContainers().map { Reminders.evaluate(it, lines, prefs, today) }
        lastLogs = db.lastLogDates()
        applyFilter()
    }

    private fun applyFilter() {
        val key = filters[b.spFilter.selectedItemPosition].first
        val q = b.etSearch.text.toString().trim().uppercase()
        val list = all.filter { e ->
            val ok = when (key) {
                "WITH" -> e.state == State.DONE
                "WITHOUT" -> e.state != State.DONE
                "UPCOMING" -> e.state == State.UPCOMING
                "OVERDUE" -> e.state == State.OVERDUE
                else -> true
            }
            ok && (q.isEmpty() || matches(e, q))
        }.sortedWith(compareBy({ -rank(it.state) }, { it.c.serial ?: Int.MAX_VALUE }, { it.c.number }))
        adapter.items = list
        adapter.notifyDataSetChanged()
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        b.tvCount.text = "${list.size} of ${all.size} containers"
    }

    private fun rank(s: State) = when (s) { State.OVERDUE -> 3; State.UPCOMING -> 2; State.OK -> 1; State.DONE -> 0 }

    private fun matches(e: Eval, q: String): Boolean {
        val iso = Iso.parse(e.c.iso)
        return e.c.number.contains(q) || e.c.iso.uppercase().contains(q) ||
            iso.category.uppercase().contains(q) || iso.description.uppercase().contains(q) ||
            (e.line?.name?.uppercase()?.contains(q) ?: false)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Add").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS or MenuItem.SHOW_AS_ACTION_WITH_TEXT)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) { startActivity(Intent(this, ContainerDetailActivity::class.java)); return true }
        return super.onOptionsItemSelected(item)
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        var items: List<Eval> = emptyList()
        inner class VH(val b: ItemContainerBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemContainerBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val e = items[i]
            val c = e.c
            h.b.tvNumber.text = c.number
            val iso = Iso.parse(c.iso)
            h.b.tvIso.text = if (c.iso.isBlank()) "ISO not set" else "${c.iso}  -  ${iso.description}"
            val (label, color) = when (e.state) {
                State.DONE -> "CERT OPENED" to R.color.green
                State.OVERDUE -> "OVERDUE" to R.color.red
                State.UPCOMING -> "DUE SOON" to R.color.amber
                State.OK -> "NO CERT" to R.color.slate
            }
            h.b.tvBadge.text = label
            h.b.tvBadge.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(ContextCompat.getColor(this@ContainerListActivity, color))
            }
            val parts = ArrayList<String>()
            parts.add(if (e.state == State.DONE) "Day ${e.days}" else "Day ${e.days} / limit ${e.threshold}")
            e.line?.let { parts.add(it.name) }
            lastLogs[c.id]?.let { parts.add("notified $it") }
            h.b.tvInfo.text = parts.joinToString("  |  ")
            h.b.root.setOnClickListener {
                startActivity(Intent(this@ContainerListActivity, ContainerDetailActivity::class.java).putExtra("id", c.id))
            }
        }
    }
}
