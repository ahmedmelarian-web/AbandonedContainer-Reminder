package com.containerreminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object Notifier {
    private const val CHANNEL = "reminders"
    const val ACTION_ALARM = "com.containerreminder.ALARM"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Container reminders", NotificationManager.IMPORTANCE_HIGH)
                    .apply { description = "Containers whose customs certificate needs follow-up" }
            )
        }
    }

    private fun alarmPending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 100, Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_ALARM),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /**
     * Arms a single alarm for the next daily check time. It re-arms itself every time it fires
     * (and after reboot / time change / app update). Uses an inexact alarm so no special
     * "exact alarm" permission is needed; delivery may be a few minutes late in Doze.
     */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmPending(ctx)
        val prefs = Prefs(ctx)
        if (!prefs.remindersEnabled) { am.cancel(pi); return }
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(prefs.notifyHour, prefs.notifyMinute)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val millis = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Posts one summary notification. [force] ignores the quiet period (used by the test button). */
    fun run(ctx: Context, force: Boolean = false): Int {
        ensureChannel(ctx)
        val prefs = Prefs(ctx)
        val db = Db.get(ctx)
        val lines = db.lines()
        val last = db.lastLogDates()
        val today = LocalDate.now()

        val due = db.allContainers()
            .map { Reminders.evaluate(it, lines, prefs, today) }
            .filter { it.state == State.OVERDUE || it.state == State.UPCOMING }
            .filter { e ->
                if (force) true else {
                    val d = last[e.c.id]?.let { Parse.date(it) }
                    d == null || ChronoUnit.DAYS.between(d, today) >= prefs.quietDays
                }
            }
        if (due.isEmpty() && !force) return 0
        if (!canPost(ctx)) return due.size

        val overdue = due.count { it.state == State.OVERDUE }
        val soon = due.size - overdue
        val summary = if (due.isEmpty()) "No containers need attention today." else buildString {
            if (overdue > 0) append("$overdue overdue")
            if (soon > 0) { if (isNotEmpty()) append(", "); append("$soon due soon") }
            append(" - customs certificate not opened")
        }
        val style = NotificationCompat.InboxStyle()
        due.sortedByDescending { it.state == State.OVERDUE }.take(6).forEach {
            style.addLine("${it.c.number}  day ${it.days}/${it.threshold}  ${if (it.state == State.OVERDUE) "OVERDUE" else "soon"}")
        }
        if (due.size > 6) style.setSummaryText("+${due.size - 6} more")

        val open = Intent(ctx, ContainerListActivity::class.java)
            .putExtra("filter", if (overdue > 0) "OVERDUE" else "UPCOMING")
        val content = PendingIntent.getActivity(
            ctx, 101, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Container Reminder")
            .setContentText(summary)
            .setStyle(style)
            .setContentIntent(content)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(1, n) } catch (_: SecurityException) { }
        return due.size
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                if (intent.action == Notifier.ACTION_ALARM) {
                    try { Notifier.run(app) } catch (_: Exception) { }
                }
                Notifier.schedule(app)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
